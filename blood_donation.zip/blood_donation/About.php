<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UOS Blood Care System</title>

    <!--ICONSCOUNT CDN-->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">

    <!--GOOGLE FONTS (MONTSERRAT)-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/about.css">
</head>

<body>
    <!--====== START OF NAVBAR =======-->
    <nav>
        <div class="container nav_container">
            <a href="index.html">
                <h2 ><b>Blood</b> Care</h2>
            </a>
            <ul class="nav_menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="About.php">About-Us</a></li>
                <li><a href="Donar-Form.php">Donar-Form</a></li>
                <li><a href="Acceptor-Form.php">Acceptor-Form</a></li>
                <li><a href="Contact.php">Contact-Us</a></li>
                <li><a href="login_panel.php">Login</a></li>
            </ul>
            <button id="open-menu-btn"><i class="uil uil-bars"></i></button>
            <button id="close-menu-btn"><i class="uil uil-multiply"></i></button>
        </div>
    </nav>
    <!--======= END OF NAVBAR ======-->

    <!-- ================ START Of About ======================== -->
    <section class="about_achievements">
        <div class="container about_achievements-container">
            <div class="about_achievements-left">
                <img src="./images/Blood_Donation-removebg-preview.png" alt="">
            </div>
            <div class="about_achievements-right">
                <h1>About Us</h1>
                <p>The "Blood Care" is responsible of maintaining records based on real data of users. It is adaptable to meet the emergency and complex needs of blood through university websites. Our purpose is to promote blood donation for world-leading health outcomes. Through the power of humanity.

                </p>  <div class="achievements_cards">
                    <article class="achievement-card">
                        <span class="achievement_icon">
                            <!-- <i class="uil uil-video"></i> -->
                        </span>
                        <h3>Why should you Donate?</h3>
                        <p>Sadly, there are still lots of patients we can’t treat because we don’t have enough supplies. There’s an urgent need for donations. Please help, if you can..</p>
                    </article>
                    <article class="achievement-card">
                        <span class="achievement_icon">
                            <!-- <i class="uil uil-users-alt"></i> -->
                        </span>
                        <h3>Did you know?</h3>
                        <p>Each whole blood donation has the potential to save up to three lives.  Your donation will give a lifeline to someone in need. Every donation counts.</p>
                    </article>
                    <article class="achievement-card">
                        <span class="achievement_icon">
                            <!-- <i class="uil uil-trophy"></i> -->
                        </span>
                        <h3>Get involved</h3>
                        <p>Help us with our mission of saving and improving lives by promoting the need for donors. Register yourself for blood donation now.</p>
                    </article>
                </div>
            </div>
        </div>
    </section>

    <!-- ================ End Of About ======================== -->

    <!-- ================ START OF TEAM ======================== -->

    <section class="team">
        <h2>Meet Our Team</h2>
        <div class="container team_container">
            <article class="team_member">
                <div class="team_member-image">
                    <img src="./images/dc72b02c-4910-48f1-be8d-21957474d861.jpg">
                </div>
                <div class="team_member-info">
                    <h4>Eman Tanveer</h4>
                    <p>Project owner</p></div>
                <div class="team_member-socials">
                    <a href="https://instagram.com" target="_blank"><i class="uil uil-instagram"></i></a>
                    <a href="https://twitter.com" target="_blank"><i class="uil uil-twitter-alt"></i></a>
                    <a href="https://linkedin.com" target="_blank"><i class="uil uil-linkedin-alt"></i></a>
                </div>
            </article>
            <article class="team_member">
                <div class="team_member-image">
                    <img src="./images/7cc253e1-35a7-436c-89bc-e44bfecb649b.jpg">
                </div>
                <div class="team_member-info">
                    <h4>Tehreem Umer</h4>
                    <p>Project Manager</p>
                </div>
                <div class="team_member-socials">
                    <a href="https://instagram.com" target="_blank"><i class="uil uil-instagram"></i></a>
                    <a href="https://twitter.com" target="_blank"><i class="uil uil-twitter-alt"></i></a>
                    <a href="https://linkedin.com" target="_blank"><i class="uil uil-linkedin-alt"></i></a>
                </div>
            </article>
            <article class="team_member">
                <div class="team_member-image">
                    <img src="./images/ayesha.jpeg">
                </div>
                <div class="team_member-info">
                    <h4>Ayesha Ijaz</h4>
                    <p>Team Member</p>
                </div>
                <div class="team_member-socials">
                    <a href="https://instagram.com" target="_blank"><i class="uil uil-instagram"></i></a>
                    <a href="https://twitter.com" target="_blank"><i class="uil uil-twitter-alt"></i></a>
                    <a href="https://linkedin.com" target="_blank"><i class="uil uil-linkedin-alt"></i></a>
                </div>
            </article>
        </div>
    </section>


    <!-- ================ End Of TEAM ======================== -->











    <!--======= Start OF Footer ======-->

    <footer>
        <div class="container footer_container">
            <div class="footer_1">
                <a href="index.html" class="footer_logo"><h4>Blood Care</h4></a>
                <p>We appreciate your donation! Your contribution will change our lives.</p>
            </div>
            <div class="footer_2">
                <h4>Permalinks</h4>
                <ul class="permalinks">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="About.html">About-Us</a></li>
                    <li><a href="Donar-Form.html">Donar-Form</a></li>
                    <li><a href="Acceptor-Form.html">Acceptor-Form</a></li>
                    <li><a href="Contact-Us.html">Contact-Us</a></li>
                    <li><a href="login_panel.html">Login</a></li>
                </ul>
            </div>
            <div class="footer_3">
                <h4>Primacy</h4>
                <ul class="privacy">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms and Conditions</a></li>
                <li><a href="#">Refund Policy</a></li>
                </ul>
            </div>
            <div class="footer_4">
                <h4>Contact Us</h4>
            <div>
                <p>+92 3041247857</p>
                <p>tehrifatima95@gmail.com</p>
            </div>
                <ul class="footer_socials">
                <li><a href="#"><i class="uil uil-facebook-f"></i></a></li>
                <li><a href="#"><i class="uil uil-instagram-alt"></i></a></li>
                <li><a href="#"><i class="uil uil-twitter"></i></a></li>
                <li><a href="#"><i class="uil uil-linkedin-alt"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="footer_copyright">
            <small>Copyright &copy; Blood Care</small>
        </div>
    </footer>
    <!--======= End OF Footer ======-->


    <script src="./main.js"></script>

</body>
</html>