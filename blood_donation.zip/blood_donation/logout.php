<?PHP
header('location:index.php');

?>