<?php 
$connect = mysqli_connect('localhost', 'root', '', 'final_project');
if($connect){
    if(isset($_POST['submit'])){
      $name=$_POST['name'];
      $cnic=$_POST['cnic'];
      $phone=$_POST['phone'];
      $address=$_POST['address'];
      $gender=$_POST['gender'];
      $age=$_POST['age'];
      $hb=$_POST['hb'];
      $weight=$_POST['weight'];
      $blood=$_POST['blood'];
      $file_name = $_FILES['pic']['name'];
      $file_temp = $_FILES['pic']['tmp_name'];
        $query = mysqli_query($connect, "INSERT INTO `acceptor_details`(`accept_id`, `name`, `cnic`, `phone`, `address`, `gender`, `age`, `hb`, `weight`, `blood_group`, `picture`) VALUES ('','$name','$cnic','$phone','$address','$gender','$age','$hb','$weight','$blood','$file_name')");
        if($query){
          move_uploaded_file($file_temp,"acceptor_pics/".$file_name);
          header("Location: index.php");
        }
        else{
          echo "picture is not valid";
        }
}
}
?>