<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UOS Blood Care System</title>

    <!--ICONSCOUNT CDN-->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">

    <!--GOOGLE FONTS (MONTSERRAT)-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/contact.css">
</head>

<body>
    <!--====== START OF NAVBAR =======-->
    <nav>
        <div class="container nav_container">
            <a href="index.html">
                <h2 ><b>Blood</b> Care</h2>
            </a>
            <ul class="nav_menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="About.php">About-Us</a></li>
                <li><a href="Donar-Form.php">Donar-Form</a></li>
                <li><a href="Acceptor-Form.php">Acceptor-Form</a></li>
                <li><a href="Contact.php">Contact-Us</a></li>
                <li><a href="login_panel.php">Login</a></li>
            </ul>
            <button id="open-menu-btn"><i class="uil uil-bars"></i></button>
            <button id="close-menu-btn"><i class="uil uil-multiply"></i></button>
        </div>
    </nav>
    <!--======= END OF NAVBAR ======-->

<section class="contact">
    <div class="container contact_container">
        <aside class="contact_aside">
            <div class="aside_image">
                <img src="images/elegantr.jpg" alt="">
            </div>
            <h2>Contact Us</h2>
            <p>Donate your blood for a reason, let the reason to be life.</p>
            <ul class="contact_details">
                <li>
                    <i class="uil uil-phone-times"></i>
                    <h5>+923041247857</h5>
                </li>
                <li>
                    <i class="uil uil-envelope"></i>
                    <h5>support@blood-donation.com</h5>
                </li>
                <li>
                    <i class="uil uil-location-point"></i>
                    <h5>UOS , Sargodha</h5>
                </li>
            </ul>
            <ul class="contact_socials">
                <li><a href="https://facebook.com"><i class="uil uil-facebook-f"></i></a></li>
                <li><a href="https://instagram.com"><i class="uil uil-instagram"></i></a></li>
                <li><a href="https://twitter.com"><i class="uil uil-twitter"></i></a></li>
                <li><a href="https://linkedin.com"><i class="uil uil-linkedin-alt"></i></a></li>
                
            </ul>
        </aside>

        <form class="contact_form">
            <div class="form_name">
                <input type="text" name="First Name" placeholder="First Name" required>
                <input type="text" name="Last Name" placeholder="Last Name" required>
            </div>
            <input type="email" name="Email Address" placeholder="Enter Your Email Address" required>
             <textarea name="Message" rows="7" placeholder="Message" required></textarea>
             <button type="submit" class="btn btn_primary">Send Message</button>
        </form>
    </div>
</section>





    <!--======= Start OF Footer ======-->

    <footer>
        <div class="container footer_container">
            <div class="footer_1">
                <a href="index.php" class="footer_logo"><h4>Blood Care</h4></a>
                <p>We appreciate your donation! Your contribution will change our lives.</p>
            </div>
            <div class="footer_2">
                <h4>Permalinks</h4>
                <ul class="permalinks">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="About.php">About-Us</a></li>
                    <li><a href="Donar-Form.php">Donar-Form</a></li>
                    <li><a href="Acceptor-Form.php">Acceptor-Form</a></li>
                    <li><a href="Contact-Us.php">Contact-Us</a></li>
                    <li><a href="login_panel.php">Login</a></li>
                </ul>
            </div>
            <div class="footer_3">
                <h4>Primacy</h4>
                <ul class="privacy">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms and Conditions</a></li>
                <li><a href="#">Refund Policy</a></li>
                </ul>
            </div>
            <div class="footer_4">
                <h4>Contact Us</h4>
            <div>
                <p>+92 3041247857</p>
                <p>tehrifatima95@gmail.com</p>
            </div>
                <ul class="footer_socials">
                <li><a href="#"><i class="uil uil-facebook-f"></i></a></li>
                <li><a href="#"><i class="uil uil-instagram-alt"></i></a></li>
                <li><a href="#"><i class="uil uil-twitter"></i></a></li>
                <li><a href="#"><i class="uil uil-linkedin-alt"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="footer_copyright">
            <small>Copyright &copy; Blood Care</small>
        </div>
    </footer>
    <!--======= End OF Footer ======-->


    <script src="./main.js"></script>

</body>
</html>