<?PHP
$con = mysqli_connect('localhost', 'root', '', 'final_project');
if($con){
    if($_GET['id']){
        $id=$_GET['id'];
        $query = mysqli_query($con, "DELETE FROM admin WHERE admin_id=$id");
        if($query){
            header('location:admin.php');
        }
    }
}
?>