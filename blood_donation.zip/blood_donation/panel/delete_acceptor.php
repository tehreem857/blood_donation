<?PHP
$con = mysqli_connect('localhost', 'root', '', 'final_project');
if($con){
    if($_GET['id']){
        $id=$_GET['id'];
        $query = mysqli_query($con, "DELETE FROM acceptor_details WHERE accept_id=$id");
        if($query){
            header('location:acceptor.php');
        }
    }
}
?>