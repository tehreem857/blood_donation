<?PHP
$con = mysqli_connect('localhost', 'root', '', 'final_project');
if($con){
    if($_GET['id']){
        $id=$_GET['id'];
        $query = mysqli_query($con, "SELECT *FROM admin WHERE `admin_id`=$id");
        $data = mysqli_fetch_array($query);
    }
}
?>





<!DOCTYPE html>
<html>
<head>
  <title>User Info</title>
  <link rel="stylesheet" type="text/css" href="">
</head>
<body>
  <div class="container">
    <h1>Admin Information</h1>
    <div class="user-info">
      <div class="user-name">
        <img src="../pictures/<?PHP echo $data['image']?>" height="200px" alt="">
      </div>
      <div class="user-name">
        <label>Name:</label>
        <span id="name"><?PHP echo $data['admin_name']?></span>
      </div>
      <div class="user-age">
        <label>CNIC:</label>
        <span id="age"><?PHP echo $data['admin_password']?></span>
      </div>
      <div class="user-email">
        <label>Phone:</label>
        <span id="email"><?PHP echo $data['authentication']?></span>
      </div>
      
      
    </div>
  </div>
  
  <script src="script.js"></script>
</body>
</html>
<style>
.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

h1 {
  text-align: center;
}

.user-info {
  margin-top: 30px;
}

.user-info label {
  font-weight: bold;
}

.user-info div {
  margin-bottom: 10px;
}

.user-info span {
  margin-left: 10px;
}
</style>
