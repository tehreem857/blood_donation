<?PHP
$connect = mysqli_connect('localhost','root','','final_project');
if($connect){
    $query = mysqli_query($connect, "SELECT * FROM `donor_details`");
    $query1 = mysqli_query($connect, "SELECT * FROM `acceptor_details`");
    $query2 = mysqli_query($connect, "SELECT * FROM `admin`");
}
$counter_donor=0;
while($donor = mysqli_fetch_array($query)){
$counter_donor++;
}


$counter_acceptor=0;
while($acceptor = mysqli_fetch_array($query1)){
$counter_acceptor++;
}

$counter_admin=0;
while($acceptor = mysqli_fetch_array($query2)){
$counter_admin++;
}











?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="navigation">
            <ul>
                <li><a href="#"><span class="icon"><i class="fab fa-apple"></i></span><span class="title">UOS Blood Care</span></a></li>
                <li><a href="#"><span class="icon"><i class="fas fa-home"></i></span><span class="title">Dashboard</span></a></li>
                <li><a href="donor.php"><span class="icon"><i class="fas fa-users"></i></span><span class="title">Donor List</span></a></li>
                <li><a href="acceptor.php"><span class="icon"><i class="fas fa-envelope"></i></span><span class="title">Acceptor List</span></a></li>
                <li><a href="#"><span class="icon"><i class="fas fa-question"></i></span><span class="title">Confirm Donor</span></a></li>
                <li><a href="#"><span class="icon"><i class="fas fa-cog"></i></span><span class="title">See Your Status</span></a></li>
                <li><a href="#"><span class="icon"><i class="fas fa-lock"></i></span><span class="title">Get Help</span></a></li>
                <li><a href="../logout.php"><span class="icon"><i class="fas fa-sign-in-alt"></i></span><span class="title">Sign Out</span></a></li>
            </ul>
        </div>
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <i class="fas fa-bars"></i>
                </div>
                <div class="search">
                    <label>
                        <!-- <input type="text" placeholder="Search Here"> -->
                        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">
                        <i class="fas fa-search"></i>
                    </label>
                </div>
                <div class="user">
                    <a href=""><img src="1.jpg"></a>
                    <!-- <a href="single_admin.php?id=<?PHP echo $data['donor_id']?>"><img src="1.jpg"></a> -->
                </div>
            </div>
            <!-- Cards -->
            <div class="cardbox">
                <div class="card">
                    <div>
                        <div class="numbers"><?PHP echo $counter_donor ?></div>
                        <div class="cardName"><a href="donor.php">Total Donor</a></div>
                    </div>
                    <div class="iconBox">
                        <a href="donor.php"><i class="far fa-eye"></i></a>
                    </div>
                </div>
                <div class="card">
                    <div>
                        <div class="numbers"><?PHP echo $counter_acceptor?></div>
                        <div class="cardName"><a href="acceptor.php">Total Acceptor</a></div>
                    </div>
                    <div class="iconBox">
                        <a href="acceptor.php"><i class="far fa-eye"></i></a>
                    </div>
                </div>
                <div class="card">
                    <div>
                        <div class="numbers"><?PHP echo $counter_acceptor+$counter_donor?></div>
                        <div class="cardName"><a href="all.php">Total Registration</a></div>
                    </div>
                    <div class="iconBox">
                        <a href="all.php"><i class="far fa-eye"></i></a>
                    </div>
                </div>
                <div class="card">
                    <div>
                        <div class="numbers"><?PHP echo $counter_admin?></div>
                        <div class="cardName"><a href="admin.php">Admin Detail</a></div>
                    </div>
                    <div class="iconBox">
                        <a href="admin.php"><i class="far fa-eye"></i></a>
                    </div>
                </div>
            </div>
            
            <div class="details">
                <!-- Order Details -->
                <div class="recentorder">
                    <div class="cardHeader">
                        <h2>Recent Donor</h2>
                        <a href="#" class="btn">View All</a>
                    </div>
                    <table id="myTable">
                        <thead>
                            <tr>
                                <td>Donor Name</td>
                                <td>Phone Number</td>
                                <td>Gender</td>
                                <td>Blood Group</td>
                                <td>Status</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?PHP
                                $i=0;
                                $query = mysqli_query($connect, "SELECT * FROM `donor_details` order by `donor_id` desc");
                                while($data = mysqli_fetch_array($query)){
                                    if($i<10){
                            ?>
                            <tr>
                                <td><?PHP echo $data['name']?></td>
                                <td><?PHP echo $data['phone']?></td>
                                <td><?PHP echo $data['gender']?></td>
                                <td><?PHP echo $data['blood_group']?></td>
                                <td><a href="single_donor.php?id=<?PHP echo $data['donor_id']?>"><?PHP echo $data['status']?></a></td>
                            </tr>
                            <?PHP
                                $i++;
                                    }
                                
                                }
                            ?>
                        </tbody>
                    </table>
                </div>

                <!-- New Customers -->
                <div class="recentCustomer">
                    <div class="cardHeader">
                        <h2>Recent Acceptor</h2>
                    </div>
                    <table>
                    <?PHP
                        $j=0;
                        $query1 = mysqli_query($connect, "SELECT * FROM `acceptor_details` order by `accept_id` desc");
                        while($data = mysqli_fetch_array($query1)){
                            if($j<6){
                    ?>
                        <tr>
                            <!-- <td><div class="imgbox"><img src="1.jpg"></div></td> -->
                            <td><div class="imgbox"><img src="../acceptor_pics/<?PHP echo $data['picture']?>"></div></td>
                            <td><h4><a href="single_acceptor.php?id=<?PHP echo $data['accept_id']?>"><?PHP echo $data['name']?></a><br><span><?PHP echo $data['blood_group']?></span></h4></td>
                            
                        </tr>
                    <?PHP
                        $j++; 
                        }
                        }
                    ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</body>
<script>
    // hovered class
    let list = document.querySelectorAll('.navigation li');
    function activeLink(){
        list.forEach((item) => 
        item.classList.remove('hovered'));
        this.classList.add('hovered');
    }
    list.forEach((item) => 
    item.addEventListener('mouseover', activeLink));

    // navigation toggle
    let toggle=document.querySelector('.toggle');
    let navigation=document.querySelector('.navigation');
    let main=document.querySelector('.main');
    toggle.onclick=function(){
        navigation.classList.toggle('active');
        main.classList.toggle('active');
    }

</script>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</html>
