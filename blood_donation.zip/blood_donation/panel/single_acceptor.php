<?PHP
$con = mysqli_connect('localhost', 'root', '', 'final_project');
if($con){
    if($_GET['id']){
        $id=$_GET['id'];
        $query = mysqli_query($con, "SELECT *FROM acceptor_details WHERE `accept_id`=$id");
        $data = mysqli_fetch_array($query);
    }
}
?>





<!DOCTYPE html>
<html>
<head>
  <title>User Info</title>
  <link rel="stylesheet" type="text/css" href="">
</head>
<body>
  <div class="container">
    <h1>Acceptor Information</h1>
    <div class="user-info">
      <div class="user-name">
        <!-- <label>Name:</label> -->
        <!-- <span id="name"><?PHP echo $data['name']?></span> -->
        <img src="../acceptor_pics/<?PHP echo $data['picture']?>" height="200px" alt="">
      </div>
      <div class="user-name">
        <label>Name:</label>
        <span id="name"><?PHP echo $data['name']?></span>
      </div>
      <div class="user-age">
        <label>CNIC:</label>
        <span id="age"><?PHP echo $data['cnic']?></span>
      </div>
      <div class="user-email">
        <label>Phone:</label>
        <span id="email"><?PHP echo $data['phone']?></span>
      </div>
      <div class="user-name">
        <label>Address:</label>
        <span id="name"><?PHP echo $data['address']?></span>
      </div>
      <div class="user-name">
        <label>Gender:</label>
        <span id="name"><?PHP echo $data['gender']?></span>
      </div>
      <div class="user-name">
        <label>Age:</label>
        <span id="name"><?PHP echo $data['age']?></span>
      </div>
      <div class="user-name">
        <label>HB:</label>
        <span id="name"><?PHP echo $data['hb']?></span>
      </div>
      <div class="user-name">
        <label>Blood Group:</label>
        <span id="name"><?PHP echo $data['blood_group']?></span>
      </div>
      <div class="user-name">
        <label>Status:</label>
        <span id="name"><?PHP echo $data['status']?></span>
      </div>
      
    </div>
  </div>
  
  <script src="script.js"></script>
</body>
</html>
<style>
.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

h1 {
  text-align: center;
}

.user-info {
  margin-top: 30px;
}

.user-info label {
  font-weight: bold;
}

.user-info div {
  margin-bottom: 10px;
}

.user-info span {
  margin-left: 10px;
}
</style>
