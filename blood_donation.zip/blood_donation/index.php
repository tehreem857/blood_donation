<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UOS Blood Care System</title>

    <!--ICONSCOUNT CDN-->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">

    <!--GOOGLE FONTS (MONTSERRAT)-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <!-- SWIPER JS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <!--====== START OF NAVBAR =======-->
    <nav>
        <div class="container nav_container">
            <a href="index.html">
                <h2><b>Blood</b> Care</h2>
            </a>
            <ul class="nav_menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="About.php">About-Us</a></li>
                <li><a href="Donar-Form.php">Donar-Form</a></li>
                <li><a href="Acceptor-Form.php">Acceptor-Form</a></li>
                <li><a href="Contact.php">Contact-Us</a></li>
                <li><a href="login_panel.php">Login</a></li>
            </ul>
            <button id="open-menu-btn"><i class="uil uil-bars"></i></button>
            <button id="close-menu-btn"><i class="uil uil-multiply"></i></button>
        </div>
    </nav>
    <!--======= END OF NAVBAR ======-->
    <!--======= Start OF Header ======-->
    <header>
        <div class="container header_container">
            <div class="header_left">
                <h1>UOS Blood Care</h1>
                <p>“A life may depend on a gesture from you, a bottle of Blood.”
                    “The Blood Donor of today may be recipient of tomorrow.”
                </p>
                <a href="#" class="btn btn-primary">Learn More</a>
            </div>
            <div class="header_right">
                <div class="header_right-img">
                    <img src="./images/h-removebg-preview.png">
                </div>
            </div>
        </div>
    </header>
    <!--======= END OF Header ======-->
    <!--======= Start OF Categories ======-->
    <section class="categories">
        <div class="container categories_container">
            <div class="categories_left">
                <h1>Why We Need To Donate Blood?</h1>
                <p>Safe blood saves lives.Every two second someone needs blood.The need for blood is 
                    constant and the blood supply must be regularly replenished.!</p>
                <a href="#" class="btn">Learn More</a>
            </div>
            <div class="categories_right">
            

                <article class="category">
                    <!-- <span class="category_icon"><i class="uil uil-megaphone"></i></span> -->
                    <h4>Donate</h4>
                    <p>Donate blood regularly.You can donate blood every 56 days.</p>
                </article>

                <article class="category">
                    <!-- <span class="category_icon"><i class="uil uil-music"></i></span> -->
                    <h4>Volunteer</h4>
                    <p>Volunteer your time to help the blood program.</p>
                </article>

                <article class="category">
                    <!-- <span class="category_icon"><i class="uil uil-puzzle-piece"></i></span> -->
                    <h4>Share</h4>
                    <p>Share the need for blood with your frinds and family 
                        and encourage them to donate.</p>
                </article>
            </div>
        </div>
    </section>
    <!--======= End OF Categories ======-->
    <!--======= Start OF Coursees ======-->
    <section class="courses">
        <h2>Donating Blood</h2>
        <div class="container courses_container">
            <article class="course">
                <div class="course_image">
                    <img src="images/blood-gdb0beba2c_1920_1655173703202_1655173717185.jpg" height="250px" alt="">
                </div>
                <div class="course_info">
                    <h4>Give Blood Give Life</h4>
                    <p>Donation can save up to 3 lives.</p>
                    <a href="course.html" class="btn btn-primary">Learn More</a>
                </div>
            </article>

            <article class="course">
                <div class="course_image">
                    <img src="images/Single-Blood-Drop.jpg" height="250px"> </img></div>
                <div class="course_info">
                    <h4>A Drop of Blood For Life</h4>
                    <p>Donate Blood and inspires others.</p>
                    <a href="course.html" class="btn btn-primary">Learn More</a>
                </div>
            </article>

            <article class="course">
                <div class="course_image">
                    <img src="images/blood1.jpg" height="250px" alt="">
                </div>
                <div class="course_info">
                    <h4>Donate Blood</h4>
                    <p>Your blood can bring a smile.</p>
                    <a href="course.html" class="btn btn-primary">Learn More</a>
                </div>
            </article>

        </div>
    </section>
    <!--======= End OF Coursees ======-->
    <!--======= Start OF FAQS ======-->
    <section class="faqs">
        <h2>Frequently Asked Questions</h2>
        <div class="container faqs_container">
            <article class="faq">
                <div class="faq_icon"><i class="uil uil-plus"></i></div>
                <div class="question_answer">
                    <h4>Who can donate blood?</h4>
                    <p>
                        A blood donor must be in good general health , be aged 18 years or older but less than 60 years, weigh at least 45 Kg, have a hemoglobin level of at least 12.5 g/dl, not have donated blood in the last 3 months
                    </p>
                </div>
            </article>

            <article class="faq">
                <div class="faq_icon"><i class="uil uil-plus"></i></div>
                <div class="question_answer">
                    <h4>How does one make sure that blood is safe?</h4>
                    <p>Some diseases can be transmitted through blood transfusion. Therefore, all donated blood is screened for transfusion transmissible diseases such as HIV, Hepatitis B, Hepatitis C, Syphilis and Malaria.

                    </p>
                </div>
            </article>

            <article class="faq">
                <div class="faq_icon"><i class="uil uil-plus"></i></div>
                <div class="question_answer">
                    <h4>Why is it important to donate blood?</h4>
                    <p>Blood can be a life-saving therapy for patients. One unit of blood can save 4 lives (if it is separated into components). Healthy people should donate blood regularly and voluntarily to overcome shortage of blood for patients. It has been proven worldwide that voluntary donations are the safest of all kinds of donations.

                    </p>
                </div>
            </article>

            <article class="faq">
                <div class="faq_icon"><i class="uil uil-plus"></i></div>
                <div class="question_answer">
                    <h4>Who cannot donate blood?</h4>
                    <p> Blood must not be donated if a person is suffering from any of these conditions, Cold/ fever in the past 1 week, Under treatment with antibiotics or any other medication, Cardiac problems, hypertension, epilepsy, diabetes (on insulin therapy), history of cancer, chronic kidney or liver disease, bleeding tendencies, venereal disease. </p>
                </div>
            </article>
        </div>
    </section>
    <!--======= End OF FAQs ======-->
    <!--======= Start OF testimonials ======-->
    <section class="container testimonials_container mySwiper">
        <h2>Affirmation</h2>
        <div class="swiper-wrapper">
            <article class="testimonial swiper-slide">
                <div class="avatar">
                    <img src="images/image-of-world-blood-donor-day.jpg" alt="">
                </div>
                <div class="testimonial_info">
                    <h5></h5>
                    <small></small>
                </div>
                <div class="testimonial_body">
                    <p> Encourage your friends and family to become a regular donor.  .
                    </p>
                </div>
            </article>

            <article class="testimonial swiper-slide">
                <div class="avatar">
                    <img src="images/image-of-world-blood-donor-day.jpg" alt="">
                </div>
                <div class="testimonial_info">
                    <h5></h5>
                    <small></small>
                </div>
                <div class="testimonial_body">
                </p>Provide care to  donors and manage blood donation session.
                    </p>
                </div>
            </article>

            <article class="testimonial swiper-slide">
                <div class="avatar">
                    <img src="images/image-of-world-blood-donor-day.jpg" alt="">
                </div>
                <div class="testimonial_info">
                    <!-- <h5></h5> -->
                    <!-- <small>Student</small> -->
                </div>
                <div class="testimonial_body">
                    <p>Blood is one of the most essential fluids of our body that helps in the smooth functioning of our body
                    </p>
                </div>
            </article>

            <article class="testimonial swiper-slide">
                <div class="avatar">
                    <img src="images/image-of-world-blood-donor-day.jpg" alt="">
                </div>
                <div class="testimonial_info">
                    <!-- <h5>Diana</h5> -->
                    <!-- <small>Student</small> -->
                </div>
                <div class="testimonial_body">
                    <p>There’s no doubt that donating blood can do a lot of goood.
                </div>
            </article>

            <article class="testimonial swiper-slide">
                <div class="avatar">
                    <img src="images/image-of-world-blood-donor-day.jpg" alt="">
                </div>
                <div class="testimonial_info">
                    <!-- <h5>Diana</h5> -->
                    <!-- <small>Student</small> -->
                </div>
                <div class="testimonial_body">
                    <p> Blood donation help get rid of negative feelings.
                    </p>
                </div>
            </article>
        </div>
        <div class="swiper-pagination"></div>
    </section>
    <!--======= End OF Testimonials ======-->
    <!--======= Start OF Footer ======-->

    <footer>
        <div class="container footer_container">
            <div class="footer_1">
                <a href="index.html" class="footer_logo">
                    <h4>Blood Care</h4>
                </a>
                <p>We appreciate your donation! Your contribution will change our lives.</p>
            </div>
            <div class="footer_2">
                <h4>Permalinks</h4>
                <ul class="permalinks">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="About.html">About-Us</a></li>
                    <li><a href="Donar-Form.html">Donar-Form</a></li>
                    <li><a href="Acceptor-Form.html">Acceptor-Form</a></li>
                    <li><a href="Contact-Us.html">Contact-Us</a></li>
                    <li><a href="login_panel.html">Login</a></li>
                </ul>
            </div>
            <div class="footer_3">
                <h4>Primacy</h4>
                <ul class="privacy">
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Terms and Conditions</a></li>
                    <li><a href="#">Refund Policy</a></li>
                </ul>
            </div>
            <div class="footer_4">
                <h4>Contact Us</h4>
                <div>
                    <p>+92 3041247857</p>
                    <p>tehrifatima95@gmail.com</p>
                </div>
                <ul class="footer_socials">
                    <li><a href="#"><i class="uil uil-facebook-f"></i></a></li>
                    <li><a href="#"><i class="uil uil-instagram-alt"></i></a></li>
                    <li><a href="#"><i class="uil uil-twitter"></i></a></li>
                    <li><a href="#"><i class="uil uil-linkedin-alt"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="footer_copyright">
            <small>Copyright &copy; Blood Care</small>
        </div>
    </footer>
    <!--======= End OF Footer ======-->



    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script src="./main.js"></script>

    <script>
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            spaceBetween: 30,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            // when window width is => 600px
            breakpoints: {
                600: {
                    slidesPerView: 2,
                }
            }
        });

    </script>

</body>

</html>