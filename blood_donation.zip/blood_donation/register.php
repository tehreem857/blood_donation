<?php 
$connect = mysqli_connect('localhost', 'root', '', 'blood_donation');
if($connect){
    if(isset($_POST['submit'])){
      $name=$_POST['uname'];
      $pass=$_POST['pass'];
      $code=$_POST['code'];
      $file_name = $_FILES['pic']['name'];
      $file_temp = $_FILES['pic']['tmp_name'];
      if($code==11223344){
        $query = mysqli_query($connect, "INSERT INTO `admin`(`admin_id`, `admin_name`, `admin_password`, `image`, `authentication`) VALUES ('','$name','$pass','$file_name','$code')");
        if($query){
          move_uploaded_file($file_temp,"pictures/".$file_name);
          header('location:login_panel.php');
        }
        else{
          echo "picture is not valid";
        }
      }
      else
        echo "Wrong authentication";
    }
}
?>