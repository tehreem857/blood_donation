<?PHP
if(isset($_POST['submit'])){
    echo $_POST['text']; 
}


?>



<html>
    <body>
        <form action="" method="post">
            <input type="text" name="text">
            <input type="submit">
        </form>
    </body>
</html>